﻿/// <reference path="../App.js" />

(function () {
    "use strict";
    //*******Global Variables********************
    var _StopCodeCount = 0;
    var _bindingID = 'NotDefined';
    var _ActiveMergeCount = 0;
    //*******************************************

    // this collection will be returned by server
    var richTextContentControlCollection = {"Controls" : [
                                                { "Key": "richTextContentControl1" },
                                                { "Key": "richTextContentControl2" },
                                                { "Key": "richTextContentControl3" },
                                                { "Key": "richTextContentControl4" },
                                                { "Key": "richTextContentControl5" },
                                                { "Key": "richTextContentControl6" },
                                                { "Key": "richTextContentControl7" }
                                        ]};

    var mergeFieldKeyValueCollection = {"MergeFieldKeyValues": [
                                                { "Key": "MergeFieldKey1", "Value": "Sample Text1" },
                                                { "Key": "MergeFieldKey2", "Value": "Sample Text2" },
                                                { "Key": "MergeFieldKey3", "Value": "Sample Text3" },
                                                { "Key": "MergeFieldKey4", "Value": "Sample Text4" },
                                                { "Key": "MergeFieldKey5", "Value": "Sample Text5" },
                                                { "Key": "MergeFieldKey6", "Value": "Sample Text6" },
                                                { "Key": "MergeFieldKey7", "Value": "Sample Text7" }
                                    ]};

    

    // The initialize function must be run each time a new page is loaded
    Office.initialize = function (reason) {
        $(document).ready(function () {
            app.initialize();

            createAllBindings();
            $(document).keyup(findStopCode);
            $('#insert-static-text').click(insertStaticText);
            $('#insert-merge-field').click(insertMergeField);
            $('#insert-merge-field-static-text').click(insertMergeFieldStaticText);
            $('#insert-phrase').click(insertPhrase);
            $('#change-color').click(changeColorForEntireDocToRed);
        });

        function changeColorForEntireDocToRed() {
            Word.run(function (ctx) {

                // Queue a command to get a content control that has the tag of "customer". 
                // Create a proxy content controls collection object.
                var range = ctx.document.getSelection();


                // Queue a command to load the text and font property on all of the content control 
                // objects in the content control collection.            
                ctx.load(range, { select: 'text', expand: 'font' });

                // Synchronize the document state by executing the queued commands,
                // and returning a promise to indicate task completion.             
                return ctx.sync().then(function () {

                    range.font.color = "#FF0000";                    
                })
                // Synchronize the document state by executing the queued commands.
                .then(ctx.sync)
                .then(function () { handleSuccess(); })
                .catch(function (error) { handleError(error); })
            });
        }

        function insertPhrase() {

            //ooXml string for doc having a rich style text
            //var phraseText = "<pkg:package xmlns:pkg=\"http://schemas.microsoft.com/office/2006/xmlPackage\">\n  <pkg:part pkg:name=\"/_rels/.rels\" pkg:contentType=\"application/vnd.openxmlformats-package.relationships+xml\" pkg:padding=\"512\">\n    <pkg:xmlData>\n      <Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">\n        <Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>\n      </Relationships>\n    </pkg:xmlData>\n  </pkg:part>\n  <pkg:part pkg:name=\"/word/document.xml\" pkg:contentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\">\n    <pkg:xmlData>\n      <!--Namespaces for vml and content earlier than Office 14 have been removed, along with the related fallback markup in the body of this part that provides info for inserting the shape into a Word 2007 document. Because a task pane app can be opened in Word 2013 in a document that is still saved in the 2007 format, you might choose to leave these in your markup. You can't insert a shape into a Word 2007 format document without them. Just remember that, if you leave the fallback markup, you'll need to leave the associated namespaces as well.-->\n      <w:document mc:Ignorable=\"w14 w15 wp14\" xmlns:wpc=\"http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas\" xmlns:mc=\"http://schemas.openxmlformats.org/markup-compatibility/2006\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:m=\"http://schemas.openxmlformats.org/officeDocument/2006/math\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:wp14=\"http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:w10=\"urn:schemas-microsoft-com:office:word\" xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:w14=\"http://schemas.microsoft.com/office/word/2010/wordml\" xmlns:w15=\"http://schemas.microsoft.com/office/word/2012/wordml\" xmlns:wpg=\"http://schemas.microsoft.com/office/word/2010/wordprocessingGroup\" xmlns:wpi=\"http://schemas.microsoft.com/office/word/2010/wordprocessingInk\" xmlns:wne=\"http://schemas.microsoft.com/office/word/2006/wordml\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><w:body><w:p w:rsidR=\"0007756C\" w:rsidRDefault=\"0007756C\" w:rsidP=\"0007756C\"><w:r w:rsidRPr=\"003C1AC4\"><w:rPr><w:b/><w:i/></w:rPr><w:t>Hello</w:t></w:r><w:r><w:t xml:space=\"preserve\"> </w:t></w:r><w:r w:rsidRPr=\"003C1AC4\"><w:rPr><w:color w:val=\"FF0000\"/></w:rPr><w:t xml:space=\"preserve\">World </w:t></w:r><w:r w:rsidRPr=\"003C1AC4\"><w:rPr><w:color w:val=\"70AD47\" w:themeColor=\"accent6\"/></w:rPr><w:t xml:space=\"preserve\">with </w:t></w:r><w:r w:rsidRPr=\"003C1AC4\"><w:rPr><w:highlight w:val=\"yellow\"/></w:rPr><w:t>style</w:t></w:r><w:r><w:t>.</w:t></w:r></w:p><w:p w:rsidR=\"00000000\" w:rsidRDefault=\"0007756C\"/><w:sectPr w:rsidR=\"00000000\"><w:pgSz w:w=\"12240\" w:h=\"15840\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" w:header=\"720\" w:footer=\"720\" w:gutter=\"0\"/><w:cols w:space=\"720\"/><w:docGrid w:linePitch=\"360\"/></w:sectPr></w:body></w:document>\n    </pkg:xmlData>\n  </pkg:part>\n</pkg:package>";

            //*********Option#1 : Worked*******************
            //Office.context.document.setSelectedDataAsync(phraseText, { coercionType: 'ooxml' });

            //*********Option#2 : Didn't work*******************
            //$.ajax({
            //    url: '../../Templates/TextWithStyle.xml',
            //    type: "Get",

            //    success: function (result) {
            //        Office.context.document.setSelectedDataAsync("Successfully called the Url...Value returned : " + result.toString());
            //    },
            //    error: function (err) {
            //        Office.context.document.setSelectedDataAsync("Error occurred..." + err.statusText.toString());
            //    }
            //});

            //*********Option#3 : Worked*******************
            var myOOXMLRequest = new XMLHttpRequest();
            var myXML;
            myOOXMLRequest.open('GET', '../../Templates/TextWithStyle.xml', false);
            myOOXMLRequest.send();

            if (myOOXMLRequest.status === 200) {
                myXML = myOOXMLRequest.responseText;
                Office.context.document.setSelectedDataAsync(myXML, { coercionType: 'ooxml' });
            }
        }

        function insertStaticText() {
            var staticText = 'STATIC-TEXT';

            //if (_bindingID == 'NotDefined') {
                Office.context.document.setSelectedDataAsync(staticText);
            //}
            //else {
            //    Office.select("bindings#" + _bindingID).setDataAsync('');
            //    Office.select("bindings#" + _bindingID).setDataAsync(staticText);
            //}
        }

        function insertMergeField() {
            //ooXml string for doc having a MergeField as «orderNoId»
            var ooXmlMergeField = "<pkg:package xmlns:pkg=\"http://schemas.microsoft.com/office/2006/xmlPackage\">\n  <pkg:part pkg:name=\"/_rels/.rels\" pkg:contentType=\"application/vnd.openxmlformats-package.relationships+xml\" pkg:padding=\"512\">\n    <pkg:xmlData>\n      <Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">\n        <Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>\n      </Relationships>\n    </pkg:xmlData>\n  </pkg:part>\n  <pkg:part pkg:name=\"/word/document.xml\" pkg:contentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\">\n    <pkg:xmlData>\n      <!--Namespaces for vml and content earlier than Office 14 have been removed, along with the related fallback markup in the body of this part that provides info for inserting the shape into a Word 2007 document. Because a task pane app can be opened in Word 2013 in a document that is still saved in the 2007 format, you might choose to leave these in your markup. You can't insert a shape into a Word 2007 format document without them. Just remember that, if you leave the fallback markup, you'll need to leave the associated namespaces as well.-->\n      <w:document xmlns:wpc=\"http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas\" xmlns:mc=\"http://schemas.openxmlformats.org/markup-compatibility/2006\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:m=\"http://schemas.openxmlformats.org/officeDocument/2006/math\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:wp14=\"http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:w10=\"urn:schemas-microsoft-com:office:word\" xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:w14=\"http://schemas.microsoft.com/office/word/2010/wordml\" xmlns:w15=\"http://schemas.microsoft.com/office/word/2012/wordml\" xmlns:wpg=\"http://schemas.microsoft.com/office/word/2010/wordprocessingGroup\" xmlns:wpi=\"http://schemas.microsoft.com/office/word/2010/wordprocessingInk\" xmlns:wne=\"http://schemas.microsoft.com/office/word/2006/wordml\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\" mc:Ignorable=\"w14 w15 wp14\">\n        <w:body>\n          <w:p w:rsidR=\"005055DE\" w:rsidRDefault=\"00CE7657\">\n            <w:fldSimple w:instr=\" MERGEFIELD  orderNoId  \\* MERGEFORMAT \">\n              <w:r>\n                <w:rPr>\n                  <w:noProof/>\n                </w:rPr>\n                <w:t>«orderNoId»</w:t>\n              </w:r>\n            </w:fldSimple>\n            <w:bookmarkStart w:id=\"0\" w:name=\"_GoBack\"/>\n            <w:bookmarkEnd w:id=\"0\"/>\n          </w:p>\n          <w:sectPr w:rsidR=\"005055DE\">\n            <w:pgSz w:w=\"12240\" w:h=\"15840\"/>\n            <w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" w:header=\"720\" w:footer=\"720\" w:gutter=\"0\"/>\n            <w:cols w:space=\"720\"/>\n            <w:docGrid w:linePitch=\"360\"/>\n          </w:sectPr>\n        </w:body>\n      </w:document>\n    </pkg:xmlData>\n  </pkg:part>\n</pkg:package>";

            //ooXml tag fragment containing the MergeField as «orderNoId»
            //var sample3 = "<w:fldSimple w:instr=\" MERGEFIELD  orderNoId  \\* MERGEFORMAT \">\n<w:r>\n<w:rPr>\n<w:noProof/>\n</w:rPr>\n<w:t>«orderNoId»</w:t>\n</w:r>\n</w:fldSimple>";

            if (_ActiveMergeCount < mergeFieldKeyValueCollection.MergeFieldKeyValues.length) {
                //1. Convert mergeField-Key from template to acctual....mergeFieldKeyCollection
                // Template : «orderNoId»
                var pattern = "orderNoId";
                var sRegExPattern = new RegExp(pattern, "g");
                var replacedWithKey = mergeFieldKeyValueCollection.MergeFieldKeyValues[_ActiveMergeCount].Key;
                ooXmlMergeField = ooXmlMergeField.replace(sRegExPattern, replacedWithKey);
                
                //2. Convert mergeField-Value from template to acctual....mergeFieldKeyCollection
                pattern = "«" + replacedWithKey + "»";
                var replacedWithValue = mergeFieldKeyValueCollection.MergeFieldKeyValues[_ActiveMergeCount].Value;
                ooXmlMergeField = ooXmlMergeField.replace(pattern, replacedWithValue);
                
                _ActiveMergeCount++;
            }
            Office.context.document.setSelectedDataAsync(ooXmlMergeField, { coercionType: 'ooxml' });

        }

        function insertMergeFieldStaticText() {
            //ooXml string for doc having a MergeField with Text
            var ooXmlMergeFieldWithText = "<pkg:package xmlns:pkg=\"http://schemas.microsoft.com/office/2006/xmlPackage\">\n  <pkg:part pkg:name=\"/_rels/.rels\" pkg:contentType=\"application/vnd.openxmlformats-package.relationships+xml\" pkg:padding=\"512\">\n    <pkg:xmlData>\n      <Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">\n        <Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>\n      </Relationships>\n    </pkg:xmlData>\n  </pkg:part>\n  <pkg:part pkg:name=\"/word/document.xml\" pkg:contentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\">\n    <pkg:xmlData>\n      <!--Namespaces for vml and content earlier than Office 14 have been removed, along with the related fallback markup in the body of this part that provides info for inserting the shape into a Word 2007 document. Because a task pane app can be opened in Word 2013 in a document that is still saved in the 2007 format, you might choose to leave these in your markup. You can't insert a shape into a Word 2007 format document without them. Just remember that, if you leave the fallback markup, you'll need to leave the associated namespaces as well.-->\n      <w:document mc:Ignorable=\"w14 w15 wp14\" xmlns:wpc=\"http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas\" xmlns:mc=\"http://schemas.openxmlformats.org/markup-compatibility/2006\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:m=\"http://schemas.openxmlformats.org/officeDocument/2006/math\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:wp14=\"http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:w10=\"urn:schemas-microsoft-com:office:word\" xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:w14=\"http://schemas.microsoft.com/office/word/2010/wordml\" xmlns:w15=\"http://schemas.microsoft.com/office/word/2012/wordml\" xmlns:wpg=\"http://schemas.microsoft.com/office/word/2010/wordprocessingGroup\" xmlns:wpi=\"http://schemas.microsoft.com/office/word/2010/wordprocessingInk\" xmlns:wne=\"http://schemas.microsoft.com/office/word/2006/wordml\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><w:body><w:p w:rsidR=\"00636B60\" w:rsidRDefault=\"00636B60\" w:rsidP=\"00636B60\"><w:r><w:fldChar w:fldCharType=\"begin\"/></w:r><w:r><w:instrText xml:space=\"preserve\"> MERGEFIELD  mergeFldTxt \\b \"Hello World\"  \\* MERGEFORMAT </w:instrText></w:r><w:r><w:fldChar w:fldCharType=\"separate\"/></w:r><w:r><w:rPr><w:noProof/></w:rPr><w:t>Hello World«mergeFldTxt»</w:t></w:r><w:r><w:rPr><w:noProof/></w:rPr><w:fldChar w:fldCharType=\"end\"/></w:r></w:p><w:p w:rsidR=\"00000000\" w:rsidRDefault=\"00636B60\"/><w:sectPr w:rsidR=\"00000000\"><w:pgSz w:w=\"12240\" w:h=\"15840\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" w:header=\"720\" w:footer=\"720\" w:gutter=\"0\"/><w:cols w:space=\"720\"/><w:docGrid w:linePitch=\"360\"/></w:sectPr></w:body></w:document>\n    </pkg:xmlData>\n  </pkg:part>\n</pkg:package>";
            Office.context.document.setSelectedDataAsync(ooXmlMergeFieldWithText, { coercionType: 'ooxml' });
            

        }

        function createAllBindings() {
            
            for (var i = 0; i < richTextContentControlCollection.Controls.length; i++) {                    
                var key = richTextContentControlCollection.Controls[i].Key;
                Office.context.document.bindings.addFromNamedItemAsync(key, "text", { id: key + "binding" }, onBindingCreated);
            }
            
           
        }

        function onBindingCreated(asyncResult) {

        }

        function onBindingReleased(asyncResult) {

        }

        function onStopCodeSelect(asyncResult) {

        }

        function findStopCode(e) {
            
            if (e.which == '120') {
               
                //Get all bindings...
                //***************This gets all bindings at runtime***********************
                Office.context.document.bindings.getAllAsync(function (asyncResult1) {
                    if (_StopCodeCount == asyncResult1.value.length) {
                        _StopCodeCount = 0;
                    }

                    for (var i in asyncResult1.value) {
                        if (i == _StopCodeCount) {
                            //
                                _bindingID = asyncResult1.value[i].id.toString();
                                Office.context.document.goToByIdAsync(asyncResult1.value[i].id.toString(), Office.GoToType.Binding);
                                Office.select("bindings#" + asyncResult1.value[i].id.toString()).getDataAsync(
                                    function (asyncResult) {
                                        var text = asyncResult.value;
                                        app.showNotification(asyncResult.value);
                                        Office.select("bindings#" + asyncResult1.value[i].id.toString()).setDataAsync(text);

                                        if (text.toUpperCase().indexOf("< - PAUSE>") < 0) {
                                            Office.context.document.bindings.releaseByIdAsync(_bindingID, onBindingReleased);
                                        }
                                    });

                            _StopCodeCount++;
                            break;
                        }                        
                    }                    
                });                
                
            }
        }



    };





































    // Reads data from current document selection and displays a notification
    function getDataFromSelection() {
        Office.context.document.getSelectedDataAsync(Office.CoercionType.Text,
            function (result) {
                if (result.status === Office.AsyncResultStatus.Succeeded) {
                    app.showNotification('The selected text is:', '"' + result.value + '"');
                } else {
                    app.showNotification('Error:', result.error.message);
                }
            }
        );
    }
})();