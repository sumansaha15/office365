﻿/// <reference path="../App.js" />

(function () {
    "use strict";
    //*******Global Variables********************
    var _StopCodeCount = 0;
    var _bindingID = 'NotDefined';
    var isBindingAdded = false;
    //*******************************************

    // this collection will be returned by server
    var richTextContentControlCollection = {"Controls" : [
                                                { "Key": "richTextContentControl1" },
                                                { "Key": "richTextContentControl2" },
                                                { "Key": "richTextContentControl3" },
                                                { "Key": "richTextContentControl4" },
                                                { "Key": "richTextContentControl5" },
                                                { "Key": "richTextContentControl6" },
                                                { "Key": "richTextContentControl7" }
                                        ]};

    // The initialize function must be run each time a new page is loaded
    Office.initialize = function (reason) {
        $(document).ready(function () {
            app.initialize();

            createAllBindings();
            $(document).keyup(findStopCode);
            $('#insert-static-text').click(insertStaticText);
            $('#insert-merge-field').click(insertMergeField);
            $('#insert-merge-field-static-text').click(insertMergeFieldStaticText);
        });

        function insertStaticText() {
            var staticText = 'STATIC-TEXT';

            if (_bindingID == 'NotDefined') {
                Office.context.document.setSelectedDataAsync(staticText);
            }
            else {
                Office.select("bindings#" + _bindingID).setDataAsync('');
                Office.select("bindings#" + _bindingID).setDataAsync(staticText);
            }
        }

        function insertMergeField() {
        }

        function insertMergeFieldStaticText() {
        }

        function createAllBindings() {
            
            //if (!isBindingAdded){
            for (var i = 0; i < richTextContentControlCollection.Controls.length; i++) {
                var key = richTextContentControlCollection.Controls[i].Key;
                Office.context.document.bindings.addFromNamedItemAsync(key, "text", { id: key + "binding" }, onBindingCreated);
            }
                //isBindingAdded = true;
            //}
            
            /*
                Office.context.document.bindings.addFromNamedItemAsync("richTextContentControl1", "text", { id: 'richTextContentControl1binding' }, onBindingCreated);
                Office.context.document.bindings.addFromNamedItemAsync("richTextContentControl2", "text", { id: 'richTextContentControl2binding' }, onBindingCreated);
                Office.context.document.bindings.addFromNamedItemAsync("richTextContentControl3", "text", { id: 'richTextContentControl3binding' }, onBindingCreated);
                Office.context.document.bindings.addFromNamedItemAsync("richTextContentControl4", "text", { id: 'richTextContentControl4binding' }, onBindingCreated);
                Office.context.document.bindings.addFromNamedItemAsync("richTextContentControl5", "text", { id: 'richTextContentControl5binding' }, onBindingCreated);
                Office.context.document.bindings.addFromNamedItemAsync("richTextContentControl6", "text", { id: 'richTextContentControl6binding' }, onBindingCreated);
                Office.context.document.bindings.addFromNamedItemAsync("richTextContentControl7", "text", { id: 'richTextContentControl7binding' }, onBindingCreated);
            */
        }

        function onBindingCreated(asyncResult) {

        }

        function onBindingReleased(asyncResult) {

        }

        function onStopCodeSelect(asyncResult) {

        }

        function findStopCode(e) {
            //debugger;

            //temp begin
            //createAllBindings();
            //temp end

            if (e.which == '120') {
                //if (_StopCodeCount == 7) {
                //    _StopCodeCount = 1;
                //}
                //else {
                //    _StopCodeCount++;
                //}

                //Get all bindings...
                //***************This gets all bindings at runtime***********************
                Office.context.document.bindings.getAllAsync(function (asyncResult1) {
                    if (_StopCodeCount == asyncResult1.value.length) {
                        _StopCodeCount = 0;
                    }

                    for (var i in asyncResult1.value) {
                        if (i == _StopCodeCount) {
                            //
                                _bindingID = asyncResult1.value[i].id.toString();
                                Office.context.document.goToByIdAsync(asyncResult1.value[i].id.toString(), Office.GoToType.Binding);
                                Office.select("bindings#" + asyncResult1.value[i].id.toString()).getDataAsync(
                                    function (asyncResult) {
                                        var text = asyncResult.value;
                                        app.showNotification(asyncResult.value);
                                        Office.select("bindings#" + asyncResult1.value[i].id.toString()).setDataAsync(text);

                                        if (text.toUpperCase().indexOf("< - PAUSE>") < 0) {
                                            Office.context.document.bindings.releaseByIdAsync(_bindingID, onBindingReleased);
                                        }
                                    });

                            _StopCodeCount++;
                            break;
                        }                        
                    }                    
                });
                
                //***************This will use already known list of bindings************
                //switch (_StopCodeCount) {
                //    case 1: Office.context.document.goToByIdAsync("richTextContentControl1binding", Office.GoToType.Binding, function (asyncResult) {
                //        if (asyncResult.status == "failed") {
                //            app.showNotification("Action failed with error: " + asyncResult.error.message);
                //        }
                //        else {
                //            app.showNotification("Navigation successful to " + asyncResult.value);
                //        }
                //    });
                //        Office.select("bindings#richTextContentControl1binding").getDataAsync(function (asyncResult) {
                //            var text = asyncResult.value;
                //            app.showNotification(asyncResult.value);
                //            Office.select("bindings#richTextContentControl1binding").setDataAsync(text);
                //        });
                //        break;
                //    case 2: Office.context.document.goToByIdAsync("richTextContentControl2binding", Office.GoToType.Binding);
                //        Office.select("bindings#richTextContentControl2binding").getDataAsync(function (asyncResult) {
                //            var text = asyncResult.value;
                //            app.showNotification(asyncResult.value);
                //            Office.select("bindings#richTextContentControl2binding").setDataAsync(text);
                //        });
                //        break;
                //    case 3: Office.context.document.goToByIdAsync("richTextContentControl3binding", Office.GoToType.Binding);
                //        Office.select("bindings#richTextContentControl3binding").getDataAsync(function (asyncResult) {
                //            var text = asyncResult.value;
                //            app.showNotification(asyncResult.value);
                //            Office.select("bindings#richTextContentControl3binding").setDataAsync(text);
                //        });
                //        break;
                //    case 4: Office.context.document.goToByIdAsync("richTextContentControl4binding", Office.GoToType.Binding);
                //        Office.select("bindings#richTextContentControl4binding").getDataAsync(function (asyncResult) {
                //            var text = asyncResult.value;
                //            app.showNotification(asyncResult.value);
                //            Office.select("bindings#richTextContentControl4binding").setDataAsync(text);
                //        });
                //        break;
                //    case 5: Office.context.document.goToByIdAsync("richTextContentControl5binding", Office.GoToType.Binding);
                //        Office.select("bindings#richTextContentControl5binding").getDataAsync(function (asyncResult) {
                //            var text = asyncResult.value;
                //            app.showNotification(asyncResult.value);
                //            Office.select("bindings#richTextContentControl5binding").setDataAsync(text);
                //        });
                //        break;
                //    case 6: Office.context.document.goToByIdAsync("richTextContentControl6binding", Office.GoToType.Binding);
                //        Office.select("bindings#richTextContentControl6binding").getDataAsync(function (asyncResult) {
                //            var text = asyncResult.value;
                //            app.showNotification(asyncResult.value);
                //            Office.select("bindings#richTextContentControl6binding").setDataAsync(text);
                //        });
                //        break;
                //    case 7: Office.context.document.goToByIdAsync("richTextContentControl7binding", Office.GoToType.Binding);
                //        Office.select("bindings#richTextContentControl7binding").getDataAsync(function (asyncResult) {
                //            var text = asyncResult.value;
                //            app.showNotification(asyncResult.value);
                //            Office.select("bindings#richTextContentControl7binding").setDataAsync(text);
                //        });
                //        break;
                    
                //}
            }
        }



    };





































    // Reads data from current document selection and displays a notification
    function getDataFromSelection() {
        Office.context.document.getSelectedDataAsync(Office.CoercionType.Text,
            function (result) {
                if (result.status === Office.AsyncResultStatus.Succeeded) {
                    app.showNotification('The selected text is:', '"' + result.value + '"');
                } else {
                    app.showNotification('Error:', result.error.message);
                }
            }
        );
    }
})();